package com.example.user.calci;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText number1, number2;
    Button Add, Sub, Mul, Div;
    TextView ViewResult;
    Double a, b, r;
    String num1, num2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        number1 = (EditText)findViewById(R.id.number1);
        number2 = (EditText)findViewById(R.id.number2);
        Add = (Button)findViewById(R.id.Add);
        Sub = (Button)findViewById(R.id.Sub);
        Mul = (Button)findViewById(R.id.Mul);
        Div = (Button)findViewById(R.id.Div);
        ViewResult = (TextView)findViewById(R.id.ViewResult);

            Add.setOnClickListener(new View.OnClickListener() { //new View in brackets
                @Override
                public void onClick(View v) {
                    Double result = conversion(1);
                    ViewResult.setText(Double.toString(result));
                }
            });

            Sub.setOnClickListener(new View.OnClickListener() { //new View in brackets
                @Override
                public void onClick(View v) {
                    Double result = conversion(2);
                    ViewResult.setText(Double.toString(result));
                }
            });

            Mul.setOnClickListener(new View.OnClickListener() { //new View in brackets
                @Override
                public void onClick(View v) {
                    Double result = conversion(3);
                    ViewResult.setText(Double.toString(result));
                }
            });

            Div.setOnClickListener(new View.OnClickListener() { //new View in brackets
                @Override
                public void onClick(View v) {
                    Double result = conversion(4);
                    ViewResult.setText(Double.toString(result));
                }
            });



    }

    public double conversion(int choice)
    {
        num1 = number1.getText().toString();
        num2 = number2.getText().toString();
        try
        {
            a = Double.parseDouble(num1);
            b = Double.parseDouble(num2);
        }
        catch (Exception e) {
            Toast.makeText(MainActivity.this, "Invalid Input", Toast.LENGTH_LONG).show();
        }
        int c=choice;
        switch(c)
        {
            case 1: r = a+b;
                break;

            case 2: r = a-b;
                break;

            case 3: r = a*b;
                break;

            case 4: if(b!=0)
            {
                r = a/b;
            }
            else
            {
                Toast.makeText(MainActivity.this, "Division by Zero: Invalid Operation", Toast.LENGTH_LONG).show();
            }
                break;
        }
        return r;

    }}



